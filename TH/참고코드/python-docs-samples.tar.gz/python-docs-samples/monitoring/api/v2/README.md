# Stackdriver Monitoring API Samples

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/monitoring/demos/

<!-- end-auto-doc-link -->
m/monitoring/api/authentication

<!-- end-auto-doc-link -->
