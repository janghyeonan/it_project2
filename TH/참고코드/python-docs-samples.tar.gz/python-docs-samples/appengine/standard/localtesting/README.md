# App Engine Local Testing Samples

These samples show how to do automated testing of App Engine applications.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/tools/localunittesting

<!-- end-auto-doc-link -->
