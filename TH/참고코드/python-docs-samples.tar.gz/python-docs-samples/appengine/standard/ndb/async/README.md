## App Engine Datastore NDB Asynchronous Operations Samples

This contains snippets used in the NDB asynchronous operations documentation,
demonstrating various ways to make asynchronous ndb operations.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/ndb/async

<!-- end-auto-doc-link -->
