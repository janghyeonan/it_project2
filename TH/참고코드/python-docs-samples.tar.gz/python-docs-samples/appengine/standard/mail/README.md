## App Engine Email Docs Snippets

This sample application demonstrates different ways to send and receive email
on App Engine


<!-- auto-doc-link -->
These samples are used on the following documentation pages:

>
* https://cloud.google.com/appengine/docs/python/mail/headers
* https://cloud.google.com/appengine/docs/python/mail/receiving-mail-with-mail-api
* https://cloud.google.com/appengine/docs/python/mail/sending-mail-with-mail-api
* https://cloud.google.com/appengine/docs/python/mail/attachments
* https://cloud.google.com/appengine/docs/python/mail/bounce

<!-- end-auto-doc-link -->
