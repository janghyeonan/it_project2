# Google App Engine XMPP

This sample includes snippets used in the [App Engine XMPP Docs](https://cloud.google.com/appengine/docs/python/xmpp/).

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/xmpp/

<!-- end-auto-doc-link -->
