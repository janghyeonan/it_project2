These scripts are used for the maintenance of this repository and are not necessarily meant as samples.
