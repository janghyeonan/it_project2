# Cloud Datastore API Samples

<!-- auto-doc-link -->
<!-- end-auto-doc-link -->
