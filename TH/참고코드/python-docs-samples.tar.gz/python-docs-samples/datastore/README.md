# Google Cloud Datastore Samples

This section contains samples for [Google Cloud Datastore](https://cloud.google.com/datastore).

## Other Samples

* [Google App Engine & NDB](../appengine/ndb).
* [Blog Sample: Introduction to Data Models in Cloud Datastore](../blog/introduction_to_data_models_in_cloud_datastore).
