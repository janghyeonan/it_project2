Python label detection [Vision API](https://cloud.google.com/vision/) example.
See the [tutorial](https://cloud.google.com/vision/docs/label-tutorial).

